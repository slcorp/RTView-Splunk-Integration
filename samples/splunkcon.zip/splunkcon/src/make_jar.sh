#!/bin/sh
# *************************************
# script to make rtvapm_influxmon.jar file

JARFILE=../lib/rtvapm_influxmon.jar
JAROPTS=cf
if [ -f $JARFILE ]; then JAROPTS=uf; fi

echo ""
echo "... Generating $JARFILE"
echo ""

cd rtfiles
jar $JAROPTS ../$JARFILE *.rtv *.xml 
if [ $? != 0 ]; then echo "Error generating $JARFILE"; 	exit 1; fi

cd ../../conf
jar uf $JARFILE *.properties

echo make_jar Ok
exit 0
