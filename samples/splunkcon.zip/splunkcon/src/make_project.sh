#!/bin/sh
# Copy files from src/rtfiles to projects/sample

ERROR_DELETE="Error cleaning up sample directory"
ERROR_COPY="Error copying files to the sample directory"

FROM=$RTVAPM_USER_HOME/influxmon/src/rtfiles
TO=$RTVAPM_USER_HOME/influxmon/projects/sample

if [ -d $TO/logs ]; then rm -f $TO/logs/*; fi
if [ $? != 0 ]; then echo $ERROR_DELETE; exit 1; fi

if [ -d $TO/measurements ]; then rm -f $TO/measurements/*; fi
if [ $? != 0 ]; then echo $ERROR_DELETE; exit 1; fi

if [ -d $TO ]; then rm -f $TO/*.*; else mkdir $TO; fi
if [ $? != 0 ]; then echo $ERROR_DELETE; exit 1; fi

#
# Copy these configuration files
#
cp $FROM/rtview.properties $TO
if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

# cp $FROM/my_alert_actions.* $TO
# if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

cp $FROM/run*.* $TO
if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

# cp $FROM/influxmon_display*.rtv $TO
# if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

#
# Copy these files to expose navtree
#
# cp $FROM/influxmon_navtree.xml $TO
# if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

#
# Create logs file and copy index
#
if [ ! -d $TO/logs ]; then mkdir $TO/logs; fi

cp $FROM/logs/index $TO/logs
if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi

if [ ! -d $TO/measurements ]; then mkdir $TO/measurements; fi

cp $FROM/measurements/.cache_defaults.rtv $TO/measurements
if [ $? != 0 ]; then echo $ERROR_COPY; exit 1; fi
