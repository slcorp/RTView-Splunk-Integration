#!/bin/sh

if [ -f ../lib/*.jar ]; then rm ../lib/*.jar; fi

./make_classes.sh
if [ $? != 0 ]; then echo "Built stopped at make_classes due to error"; exit 1; fi

./make_jar.sh
if [ $? != 0 ]; then echo "Built stopped at make_jar due to error"; exit 1; fi

./make_project.sh
if [ $? != 0 ]; then echo "Built stopped at make_project due to error"; exit 1; fi

./make_wars.sh
if [ $? != 0 ]; then echo "Built stopped at make_wars.sh due to error"; exit 1; fi

exit 0