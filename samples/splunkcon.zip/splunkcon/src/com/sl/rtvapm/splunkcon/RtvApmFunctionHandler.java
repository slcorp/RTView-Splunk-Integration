//*******************************************************************
// SL-GMS Enterprise RtView Examples
// RtvApmFunctionHandler: Custom RTVAPM Function Handler
// Copyright (c) 2011 Sherrill-Lubinski Corporation. All Rights Reserved.
// 28 October 2011
//********************************************************************

package com.sl.rtvapm.splunkcon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
//import java.net.Authenticator;
import javax.net.ssl.HttpsURLConnection;

import java.net.ConnectException;
import java.net.HttpURLConnection;
//import java.net.InetAddress;
import java.net.URL;
import java.text.DecimalFormat;
//import java.net.*;
import java.util.*;

import com.sl.gmsjrt.*;
import com.sl.gmsjrtview.*;
//import com.sl.gmsjcacheds.*;
//import com.sl.gmsjrtvutils.*;


/* This class contains a Custom Function Handler.
 */

public class RtvApmFunctionHandler extends GmsRtViewCustomFunctionHandler
{

	// **************************************************************
	// FUNCTION TABLE

	public Vector<GmsRtViewFunctionDescriptor> getFunctionDescriptors ()
	{
		// vector of function descriptors

		Vector<GmsRtViewFunctionDescriptor> v =
				new Vector<GmsRtViewFunctionDescriptor>();

		// TEST
		{
			GmsRtViewFunctionArgument args[] = {
					new GmsRtViewFunctionArgument("Value", GMS.G_STRING),
			};

			v.addElement(new GmsRtViewFunctionDescriptor("_________COLLECTDCON_________",
					args,
					GMS.G_STRING, null,
					"This function returns the input string.\n",
					"This function returns the input string.\n" +
							"It is used to test access to collectcon functions" +
							"It also marks the beginning of collectcon functions",
							false));
		}

		// Send table to Splunk
		{
			GmsRtViewFunctionArgument args[] = {
					new GmsRtViewFunctionArgument("URL", GMS.G_STRING),
					new GmsRtViewFunctionArgument("Token", GMS.G_STRING),
					new GmsRtViewFunctionArgument("TableName", GMS.G_STRING),
					new GmsRtViewFunctionArgument("Source", GMS.G_STRING),
					new GmsRtViewFunctionArgument("HostColumn", GMS.G_STRING),
					new GmsRtViewFunctionArgument("TimeColumn", GMS.G_STRING),
					new GmsRtViewFunctionArgument("TableToSend", GMS.G_TABLE),
			};

			v.addElement(new GmsRtViewFunctionDescriptor("SENDSPLUNK", args,
					GMS.G_INTEGER, null,
					"Send table to splunk over TCP",
					"Each row of the table is formatted as a JSON event with following metadata:\n" +
					"time - timestamp from TimeColumn parameter\n" +
					"host - string from HostColumn parameter (if host is not available, choose a suitable index column)\n" +
					"source - string name of the dataserver that collected the data\n" +
					"sourcetype - string from TableName parameter\n" +
					"HostColumn and TimeColumn should be names of columns in the TableToSend.\n" +
					"\nRemaining columns in table are sent as a JSON array bound to event metadata tag.",
					false));
		}

		return v;
	}

	// **************************************************************
	// FUNCTION RESULT METHODS

	public String getStringResult (String functionName,
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon)
	{
		String ret = "";

		if (functionName.equals("_________COLLECTDCON_________"))
			return getCustomTest(functionDesc, functionIcon);

		return ret;
	}

	public double getDoubleResult (String functionName,
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon)
	{
		double ret = 0.0;
		return ret;
	}

	public int getIntResult (String functionName,	
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon)
	{
		int result = 0;

		if (functionName.equals("SENDSPLUNK"))
			return sendSplunk(functionDesc, functionIcon);

		return result;
	}


	public GmsTabularData getTabularResult (String functionName,	
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon)
	{
		GmsTabularData resultTable = null;

		//if (functionName.equals("SENDSPLUNK"))
		//	return sendSplunk(functionDesc, functionIcon);

		return resultTable;
	}

	// ************************************************************
	// TEST

	private String getCustomTest (
			GmsRtViewFunctionDescriptor functionDesc,
			GmsModelVariables functionIcon)
	{
		try {
			return functionDesc.getArgStringValue("Value", functionIcon);
		} catch (Exception ex) {
			printErrorMessage(functionIcon,"ERROR: " + ex);
			ex.printStackTrace();
		}

		return "";
	}

	// ************************************************************
	// SEND SPLUNK
	static final Map<String,String> jsonReservedNames;
	static { //TODO - put these choices in a properties file
		jsonReservedNames = new HashMap<String,String>();
		jsonReservedNames.put( "source", "raw_source");
		jsonReservedNames.put( "sourcetype", "raw_sourcetype");
		jsonReservedNames.put( "event", "raw_event");
	}
	
	public int sendSplunk (GmsRtViewFunctionDescriptor functionDesc, GmsModelVariables functionIcon)
	{
		int numSent=0;
		try {
			String token = functionDesc.getArgStringValue("Token", functionIcon);
			String source = functionDesc.getArgStringValue("Source", functionIcon);
			String hostColumn = functionDesc.getArgStringValue("HostColumn", functionIcon);
			String timeColumn = functionDesc.getArgStringValue("TimeColumn", functionIcon);
			String urlStr =  functionDesc.getArgStringValue("URL", functionIcon);
			GmsTabularData table = functionDesc.getArgTableValue("TableToSend", functionIcon);
			String tableName =  functionDesc.getArgStringValue("TableName", functionIcon);

			if (table == null) return -1;
			// only update if TableToSend has changed (since this
			// is an immediate update function)
			obj_function funObj = (obj_function)functionIcon;
			GmsRtViewFunctionDescriptor fDesc = funObj.getFuncDesc();
			if (fDesc == null) {
				//debug("no fdesc");
				return -1;
			}
			List<String> updatedArgs = fDesc.getNamesOfUpdatedArgs(functionIcon);
			boolean updated = false;
			if (updatedArgs != null) {
				for (String argName : updatedArgs) {
					if (argName.equals("TableToSend"))
						updated = true;
				}
			}
			if(!updated || table.getNumRows() == 0) return -1;

			int timeCol = table.getColumnIndex(timeColumn);
			int hostCol = table.getColumnIndex(hostColumn);
			//String[] colName = table.getColumnNames();
			List<String> eventCol = new ArrayList<String>();
			List<Integer> eventColType = new ArrayList<Integer>();
			for(int i=0; i < table.getNumColumns(); i++){
				String s = table.getColumnName(i);
				if(!(s.equals(timeColumn) || s.equals(hostColumn))) {
					eventCol.add(s);
				}
			}
			if(timeCol < 0 || hostCol < 0) {
				printErrorMessage(functionIcon,"Invalid host or time column name");
				return -1;
			}
			int[] colIndx = table.getColumnIndexArray(eventCol.toArray(new String[eventCol.size()]));
			for(int i: colIndx) eventColType.add(table.getColumnTypeCode(i));
			//System.out.println("array size: " + eventCol.size() + " columns, "+ table.getNumRows() + " rows");

			//send the events
			HttpsURLConnection httpConn = null;
			OutputStream out = null;
			OutputStreamWriter wout = null;
			//wout = new OutputStreamWriter(System.out, CHARSET); // test - dump json to console
			int MAX_BUFFER_SIZE = 1000000;
			int byteCounter = 0;
			for(int row=0; row < table.getNumRows(); row++) {
				if(wout == null) {
					httpConn = openHttpsURL(token, urlStr);
					wout = new OutputStreamWriter(httpConn.getOutputStream(), CHARSET);					
				}
				String eventMetadata = "{" +
						"\"time\": " + new DecimalFormat("#.000").format(table.getLongCellValue(row, timeCol)/1000.0) +
						", \"host\": \"" + table.getCellValue(row, hostCol) + "\"" +
						", \"source\": \"" + source + "\"" +
						", \"sourcetype\": \"" + tableName + "\"" +
						", \"event\": {";
				byteCounter += eventMetadata.length();
				wout.write(eventMetadata);
				for(int col=0; col < eventCol.size(); col++) {
					String colName = eventCol.get(col);
					if(jsonReservedNames.containsKey(colName)) colName = jsonReservedNames.get(colName);
					if(col == 0)
						wout.write("\"" + colName + "\":");
					else {
						wout.write(",\"" + colName + "\":");
						byteCounter++;
					}
					byteCounter += colName.length();
						
					int type = eventColType.get(col);
					switch(type) {
					case GmsTabularData.STRING:
					case GmsTabularData.DATE:
						String quotedParm = quote(table.getCellValue(row, colIndx[col]));
						wout.write(quotedParm);
						byteCounter += quotedParm.length();
						break;
					case GmsTabularData.DOUBLE:
						Double d = table.getDoubleCellValue(row, colIndx[col]);
						if(d.isNaN()) d = 0.0;
						wout.write(String.valueOf(d));
						byteCounter += Double.SIZE;
						break;
					default:
						wout.write(table.getCellValue(row, colIndx[col]));
						break;
					}
					
				}
				wout.write("}}");
				byteCounter += 2;
				if(byteCounter >= MAX_BUFFER_SIZE) {
					wout.flush(); wout.close(); wout = null;
					processSplunkResponse(functionIcon, httpConn);
					byteCounter = 0;
				}
			}
			if(wout != null) {
				wout.flush(); wout.close(); wout = null;
				processSplunkResponse(functionIcon, httpConn);
			}
			numSent = table.getNumRows();
		} catch (ConnectException ex) {
			printErrorMessage(functionIcon,"Splunk is down: " + ex.getLocalizedMessage());
		} catch (Exception ex) {
			printErrorMessage(functionIcon,"ERROR: " + ex);
			ex.printStackTrace();
		}
		return numSent;

	}
	
	static {
	    //for localhost testing only
	    javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
	    new javax.net.ssl.HostnameVerifier(){

	        public boolean verify(String hostname,
	                javax.net.ssl.SSLSession sslSession) {
	            if (hostname.equals("localhost")) {
	                return true;
	            }
	            return true;
	        }
	    });
	}

	final String CHARSET = "utf-8";
	private HttpsURLConnection openHttpsURL(String token, String url) 
			throws Exception {
		HttpsURLConnection connection = null;
			URL u = new URL(url);
			connection = (HttpsURLConnection) u.openConnection();
			connection.setDoOutput(true);
			connection.setDoInput(true);
			connection.setInstanceFollowRedirects(false); 
			connection.setRequestMethod("POST"); 
			connection.setRequestProperty("Content-Type", "text/json"); 
			connection.setRequestProperty("accept-charset", CHARSET);
			connection.setRequestProperty("Authorization", "Splunk "+token);
			//connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setUseCaches (false);
			connection.setConnectTimeout(5000);
			
			//Authenticator not needed for splunk - authorization token used instead
			//Authenticator.setDefault(new MyAuthenticator(username, password));
		return connection;
	}

	private void processSplunkResponse(
			GmsModelVariables functionIcon,
			HttpURLConnection connection
			) throws Exception {
		

		int responseCode = connection.getResponseCode();
		if( responseCode == 200 ) {
			StringBuilder response = new StringBuilder();
			//collect the response
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(),"UTF-8"));
			String line;
			while ((line = br.readLine()) != null) {
				response.append(line);
			}
			br.close();
			String r = new String(response);
			//System.out.println("--> Splunk response: "+r);

			if(!r.contains("Success")) printErrorMessage(functionIcon,"*** Splunk failed with " + r);
		} else {
			//System.out.println("--> Splunk could not process event - error code: "+responseCode);
			printErrorMessage(functionIcon,"*** Splunk failed with HTTP response " + responseCode);
		}
	}

	public static String quote(String string) {
        if (string == null || string.length() == 0) {
            return "\"\"";
        }

        char         c = 0;
        int          i;
        int          len = string.length();
        StringBuilder sb = new StringBuilder(len + 4);
        String       t;

        sb.append('"');
        for (i = 0; i < len; i += 1) {
            c = string.charAt(i);
            switch (c) {
            case '\\':
            case '"':
                sb.append('\\');
                sb.append(c);
                break;
            case '/':
//                if (b == '<') {
                    sb.append('\\');
//                }
                sb.append(c);
                break;
            case '\b':
                sb.append("\\b");
                break;
            case '\t':
                sb.append("\\t");
                break;
            case '\n':
                sb.append("\\n");
                break;
            case '\f':
                sb.append("\\f");
                break;
            case '\r':
               sb.append("\\r");
               break;
            default:
                if (c < ' ') {
                    t = "000" + Integer.toHexString(c);
                    sb.append("\\u" + t.substring(t.length() - 4));
                } else {
                    sb.append(c);
                }
            }
        }
        sb.append('"');
        return sb.toString();
    }
}