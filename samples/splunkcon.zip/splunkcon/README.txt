Splunk RTView Monitor for Tibco BusinessWorks

Introduction
============
In version 6.3, Splunk added the HTTP Event Collector (HEC), "a new,
robust, token-based JSON API for sending events to Splunk from 
anywhere without requiring a forwarder. It is designed for 
performance and scale. Using a load balancer in front, it can be
deployed to handle millions of events per second. It is highly
available and it is secure. It is easy to configure, easy to use,
and best of all it works out of the box.* A few other cool tidbits,
it supports gzip compression, batching, HTTP keep-alive and HTTP/HTTPs."
(http://blogs.splunk.com/2015/10/06/http-event-collector-your-direct-event-pipe-to-splunk-6-3/)

SL's RTView dataserver collects monitoring data from a variety of 
host, application, and middleware components, and has been extended
to forward this data to Splunk via the HEC. For demonstration purposes,
this article shows how Tibco BusinessWorks data can be pushed to Splunk 
and visualized by a new Splunk app developed for this purpose. Given
the sample displays and associated Splunk searches, we expect that
Splunk users can easily further customize this app for their specific needs.

Given the generic function of the new RTView Splunk connector, it is 
easy to forward any data collected by RTView to Splunk, opening the door
for a plethora of opportunities for analysis of data not previously 
available to Splunk.

Prerequisites
=============
Splunk 6.3 or later
RTView dataserver configured to collect Tibco BusinessWorks metrics

Installation
============
1. Download and install this app.
   a) In your browser, login to Splunk as an administrator 
      and navigate to Apps -> Manage Apps".
   b) Click "Install app from file".
   c) Browse to and select downloaded app file, then click "Upload".


Splunk Configuration
====================
1. Create a new index for data sent by RTView dataservers.
   a) In your browser, navigate to "Settings -> Indexes".
   b) Click "New Index".
   c) Enter "rtviewdata" for the "Index Name", select "RTView Monitor for Tibco
      BusinessWorks" for the "App", and click "Save".
Note: if you change the index name, you will need to update the saved queries for this app.

2. Enable the "HTTP EventCollector".
See "http://docs.splunk.com/Documentation/Splunk/6.5.0/Data/UsetheHTTPEventCollector"
for setup and use of Splunk's HTTP Event Collector.
   a) In your browser, navigate to "Settings -> Data Inputs".
   b) Click "New Token".
   c) Enter "rtviewstream" for the token "Name", and click "Next".
   d) Click on "rtviewdata" in "Select Allowed Indexes" and click "Review".
   e) Click "Submit".
   f) Copy the token for use in "RTView Configuration". It will be a string similar to the following:
      39B11BA2-589C-4BD4-9542-BEA103A31A2C
   g) Click "Global Settings". Click "Enabled" for "All Tokens" and "Save".
Note: TCP port 8088 must be open on the server hosting splunk and not blocked
by the host firewall.

RTView Configuration
====================
Configure your RTView Dataserver to forward data to Splunk.
1. Starting with a dataserver already configured to collect data from
  a farm of Tibco BusinessWorks engines, install the new
  "splunkcon" Solution Package.
  Refer to the instructions in the sample.properties file for
  splunkcon. You will paste the token from step 2f (above) 
  into the appropriate property in that file and uncomment
  the appropriate "sender" config file (bw_splunk_sender.rtv).
  
2. Avoid dataserver-to-Splunk connection failures by adding Splunk's certificate to your
java JRE's certificate store on the host that will run the RTView dataserver. The
certificate will be unique for each splunk instance, so you will need to add the
certificate for your instance to the keystore.

If you have not created your own key store, then the default key store is 
"%JAVA_HOME%\jre\lib\security\cacerts". YOu can check to see if the key store
already contains a splunk certificate as follows:

keytool -list -v -keystore "%JAVA_HOME%\jre\lib\security\cacerts" | grep splunk

If the store already contains an older Splunk certificate, then 
delete it as follows:
	 > keytool -delete -alias SplunkServerDefaultCert -keystore "%JAVA_HOME%\jre\lib\security\cacerts"
	   
Fetch the new certificate and add it to the store, using the "openssl"
command available in either cygwin or linux (or use browser - see note):
	> openssl s_client -connect <server name or IP>:<port>
	   
The output of openssl should include the following, which you should
copy and paste into a file named SplunkServerDefaultCert.pem:
-----BEGIN CERTIFICATE-----
MIICdTCCAd4CCQDlsvzBaZf1RjANBgkqhkiG9w0BAQUFADB/MQswCQYDVQQGEwJV
UzELMAkGA1UECAwCQ0ExFjAUBgNVBAcMDVNhbiBGcmFuY2lzY28xDzANBgNVBAoM
...
-----END CERTIFICATE-----
	   
Add the certificate to the store as follows:
	> keytool -import -v -trustcacerts -alias SplunkServerDefaultCert -file SplunkServerDefaultCert.pem -keystore "%JAVA_HOME%\jre\lib\security\cacerts"
	   
Note: The default password for java keystore is "changeit".
Use the "-list" option of keytool to verify that the certificate was
successfully imported.
	   
3. Start the dataserver to begin forwarding data to Splunk.

Note: As an alternative to openssl, you can obtain the splunk certificate using firefox.
Simply enter the Splunk HEC URL (https://localhost:8088) in your browser, then add an exception  
to enter the certificate in firefox's certificate store. Then use "Tools -> Options -> Advanced" 
to view and export the certificate.

View Displays in Splunk App
===========================
As the dataserver sends data to Splunk, the various displays
in the app will begin to populate.